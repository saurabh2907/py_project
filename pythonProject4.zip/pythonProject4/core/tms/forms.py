# forms.py in the tms app

from django import forms
from .models import TrainingProgram, TrainingMaterial, TrainingModule, Quiz, Trainer, TrainingSession

class TrainingProgramForm(forms.ModelForm):
    class Meta:
        model = TrainingProgram
        fields = ['title', 'category', 'description', 'duration_in_days', 'start_date', 'end_date']

class TrainingMaterialForm(forms.ModelForm):
    class Meta:
        model = TrainingMaterial
        fields = ['title', 'material_file', 'content_type', 'description']

class TrainingModuleForm(forms.ModelForm):
    class Meta:
        model = TrainingModule
        fields = ['title', 'content', 'order']

class QuizForm(forms.ModelForm):
    class Meta:
        model = Quiz
        fields = ['module', 'question', 'options', 'correct_answer']

class TrainerForm(forms.ModelForm):
    class Meta:
        model = Trainer
        fields = ['user', 'expertise', 'bio']

class TrainingSessionForm(forms.ModelForm):
    class Meta:
        model = TrainingSession
        fields = ['program', 'trainer', 'start_datetime', 'end_datetime', 'location']


# forms.py in the tms app

from django import forms
from .models import TrainingRequest

class TrainingRequestForm(forms.ModelForm):
    class Meta:
        model = TrainingRequest
        fields = ['requested_program', 'reason']

