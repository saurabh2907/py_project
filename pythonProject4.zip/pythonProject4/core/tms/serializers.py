from rest_framework import serializers
from .models import *

class TrainingCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainingCategory
        fields = '__all__'

class TrainingProgramSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainingProgram
        fields = '__all__'

class TrainingRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainingRequest
        fields = '__all__'

class TrainingRoomSerializer(models.Model):
    class Meta:
        model = TrainingRoom
        fields ='__all__'

class TrainingModuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainingModule
        fields = '__all__'

class QuizSerializer(serializers.ModelSerializer):
    class Meta:
        model = Quiz
        fields = '__all__'

class TrainerUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainerUpdate
        fields = '__all__'

class ParticipantFeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = ParticipantFeedback
        fields = '__all__'
