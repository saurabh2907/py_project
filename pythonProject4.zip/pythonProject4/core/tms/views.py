from rest_framework import generics
from .models import TrainingCategory, TrainingProgram
from .serializers import TrainingCategorySerializer, TrainingProgramSerializer

class TrainingCategoryList(generics.ListCreateAPIView):
    queryset = TrainingCategory.objects.all()
    serializer_class = TrainingCategorySerializer

class TrainingCategoryDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = TrainingCategory.objects.all()
    serializer_class = TrainingCategorySerializer

class TrainingProgramList(generics.ListCreateAPIView):
    queryset = TrainingProgram.objects.all()
    serializer_class = TrainingProgramSerializer

class TrainingProgramDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = TrainingProgram.objects.all()
    serializer_class = TrainingProgramSerializer
