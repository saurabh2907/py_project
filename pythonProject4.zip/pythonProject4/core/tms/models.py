from django.db import models
from core.accounts.models import CustomUser

class TrainingCategory(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class TrainingProgram(models.Model):
    title = models.CharField(max_length=200)
    category = models.ForeignKey(TrainingCategory, on_delete=models.CASCADE)
    description = models.TextField()
    duration_in_days = models.PositiveIntegerField()

    def __str__(self):
        return self.title


class TrainingRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    employee = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    requested_program = models.ForeignKey(TrainingProgram, on_delete=models.CASCADE)
    reason = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    request_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Request from {self.employee} for {self.requested_program}"


class TrainingRoom(models.Model):
    name = models.CharField(max_length=100, unique=True)
    capacity = models.PositiveIntegerField()

    def __str__(self):
        return self.name


class RoomAvailability(models.Model):
    room = models.ForeignKey(TrainingRoom, on_delete=models.CASCADE)
    date = models.DateField()
    is_available = models.BooleanField(default=True)

    def __str__(self):
        status = "Available" if self.is_available else "Not Available"
        return f"{self.room} - {self.date} - {status}"


class Trainer(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    expertise = models.CharField(max_length=200)
    bio = models.TextField()

    def __str__(self):
        return self.user.username

class TrainingSession(models.Model):
    program = models.ForeignKey(TrainingProgram, on_delete=models.CASCADE)
    trainer = models.ForeignKey(Trainer, on_delete=models.CASCADE)
    start_datetime = models.DateTimeField()
    end_datetime = models.DateTimeField()
    location = models.CharField(max_length=200)
    available_slots = models.PositiveIntegerField()
    room = models.ForeignKey(TrainingRoom, on_delete=models.CASCADE)  # New field

    def __str__(self):
        return f"{self.program} - {self.start_datetime} to {self.end_datetime}"


class SessionStatus(models.Model):
    session = models.OneToOneField(TrainingSession, on_delete=models.CASCADE)
    is_completed = models.BooleanField(default=False)
    start_time_actual = models.DateTimeField(null=True, blank=True)
    end_time_actual = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.session} - Completed: {self.is_completed}"



class SessionAttendance(models.Model):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE)
    employee = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    attended = models.BooleanField(default=False)

    def __str__(self):
        status = "Attended" if self.attended else "Not Attended"
        return f"{self.employee} - {self.session} - {status}"


class Notification(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user}: {self.message}"



class TrainingMaterial(models.Model):
    program = models.ForeignKey(TrainingProgram, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    material_file = models.FileField(upload_to='training_materials/')
    content_type = models.CharField(max_length=50)
    description = models.TextField()

    def __str__(self):
        return self.title


class TrainingModule(models.Model):
    program = models.ForeignKey(TrainingProgram, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    content = models.TextField()  # HTML content for module
    order = models.PositiveIntegerField()

    def __str__(self):
        return self.title


class Quiz(models.Model):
    module = models.ForeignKey(TrainingModule, on_delete=models.CASCADE)
    question = models.TextField()
    options = models.JSONField()  # List of answer choices
    correct_answer = models.PositiveIntegerField()  # Index of correct option

    def __str__(self):
        return self.question


# models.py in the tms app

class TrainerUpdate(models.Model):
    trainer = models.ForeignKey(Trainer, on_delete=models.CASCADE)
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE)
    update_date = models.DateTimeField(auto_now_add=True)
    update_message = models.TextField()

    def __str__(self):
        return f"{self.trainer} - {self.session} - {self.update_date}"



class ParticipantFeedback(models.Model):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE)
    participant = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    feedback_text = models.TextField()
    rating = models.PositiveIntegerField(choices=[(i, i) for i in range(1, 6)])

    def __str__(self):
        return f"{self.participant} - {self.session}"


class TrainingRequestManager(models.Manager):
    def pending_requests(self):
        return self.filter(status='pending')

    def approved_requests(self):
        return self.filter(status='approved')

    def rejected_requests(self):
        return self.filter(status='rejected')


class TrainingRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    sender = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='sent_requests')
    receiver = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='received_requests')
    receiver_type = models.CharField(max_length=10)  # 'manager' or 'trainer'
    requested_program = models.ForeignKey(TrainingProgram, on_delete=models.CASCADE)
    reason = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    request_date = models.DateTimeField(auto_now_add=True)
    reply = models.TextField(blank=True, null=True)
    reply_date = models.DateTimeField(blank=True, null=True)
    objects = TrainingRequestManager()

    def __str__(self):
        return f"Request from {self.sender} to {self.receiver} for {self.requested_program}"

# models.py in the tms app

class TrainingSession(models.Model):
    sender = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='sent_sessions')
    receiver = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='received_sessions')
    training_request = models.ForeignKey(TrainingRequest, on_delete=models.CASCADE)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    status = models.CharField(max_length=20, choices=SESSION_STATUS_CHOICES)
    attendance = models.ManyToManyField(CustomUser, related_name='attended_sessions')
    feedback = models.TextField(blank=True, null=True)


# models.py in the tms app

class TrainingSession(models.Model):
    # Existing fields...
    scheduled_date = models.DateField()
    scheduled_start_time = models.TimeField()
    scheduled_end_time = models.TimeField()


class Attendance(models.Model):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE)
    employee = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    marked = models.BooleanField(default=False)

# models.py in the tms app

class TrainerFeedbackQuestion(models.Model):
    question_text = models.TextField()

class TrainerFeedback(models.Model):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE)
    question = models.ForeignKey(TrainerFeedbackQuestion, on_delete=models.CASCADE)
    feedback_text = models.TextField()

    def __str__(self):
        return f"Trainer Feedback for Session {self.session}"



# models.py in the tms app

class ModuleFeedbackQuestion(models.Model):
    question_text = models.TextField()

class ModuleFeedback(models.Model):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE)
    question = models.ForeignKey(ModuleFeedbackQuestion, on_delete=models.CASCADE)
    feedback_text = models.TextField()

    def __str__(self):
        return f"Module Feedback for Session {self.session}"
