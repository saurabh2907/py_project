# views.py in the tms app

from django.shortcuts import render
from .models import TrainingProgram

def training_program_list(request):
    programs = TrainingProgram.objects.all()
    return render(request, 'tms/program_list.html', {'programs': programs})

def training_program_detail(request, program_id):
    program = TrainingProgram.objects.get(pk=program_id)
    return render(request, 'tms/program_detail.html', {'program': program})

# views.py in the tms app

from django.shortcuts import render
from .models import TrainingMaterial

def training_material_detail(request, material_id):
    material = TrainingMaterial.objects.get(pk=material_id)
    return render(request, 'tms/material_detail.html', {'material': material})


# views.py in the tms app

from django.shortcuts import render
from .models import TrainingModule

def training_module_detail(request, module_id):
    module = TrainingModule.objects.get(pk=module_id)
    return render(request, 'tms/module_detail.html', {'module': module})


# views.py in the tms app

from django.shortcuts import render
from .models import Quiz

def quiz_detail(request, quiz_id):
    quiz = Quiz.objects.get(pk=quiz_id)
    return render(request, 'tms/quiz_detail.html', {'quiz': quiz})


# views.py in the tms app

from django.shortcuts import render
from .models import Trainer

def trainer_list(request):
    trainers = Trainer.objects.all()
    return render(request, 'tms/trainer_list.html', {'trainers': trainers})

def trainer_detail(request, trainer_id):
    trainer = Trainer.objects.get(pk=trainer_id)
    return render(request, 'tms/trainer_detail.html', {'trainer': trainer})


# views.py in the tms app

from django.shortcuts import render
from .models import TrainingSession

def training_session_list(request):
    sessions = TrainingSession.objects.all()
    return render(request, 'tms/session_list.html', {'sessions': sessions})

def training_session_detail(request, session_id):
    session = TrainingSession.objects.get(pk=session_id)
    return render(request, 'tms/session_detail.html', {'session': session})
----------------------------
# views.py in the tms app

from django.shortcuts import render, get_object_or_404, redirect
from .models import TrainingProgram
from .forms import TrainingProgramForm

def training_program_list(request):
    programs = TrainingProgram.objects.all()
    return render(request, 'tms/program_list.html', {'programs': programs})

def training_program_detail(request, program_id):
    program = get_object_or_404(TrainingProgram, pk=program_id)
    return render(request, 'tms/program_detail.html', {'program': program})

def create_training_program(request):
    if request.method == 'POST':
        form = TrainingProgramForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('training_program_list')
    else:
        form = TrainingProgramForm()
    return render(request, 'tms/create_program.html', {'form': form})

def update_training_program(request, program_id):
    program = get_object_or_404(TrainingProgram, pk=program_id)
    if request.method == 'POST':
        form = TrainingProgramForm(request.POST, instance=program)
        if form.is_valid():
            form.save()
            return redirect('training_program_list')
    else:
        form = TrainingProgramForm(instance=program)
    return render(request, 'tms/update_program.html', {'form': form, 'program': program})

def delete_training_program(request, program_id):
    program = get_object_or_404(TrainingProgram, pk=program_id)
    if request.method == 'POST':
        program.delete()
        return redirect('training_program_list')
    return render(request, 'tms/delete_program.html', {'program': program})


---------
# views.py in the tms app

from django.shortcuts import render, get_object_or_404, redirect
from .models import TrainingMaterial
from .forms import TrainingMaterialForm

# Similar to training_program_list, training_program_detail, create_training_program, etc.
# ...

def create_training_material(request, program_id):
    program = get_object_or_404(TrainingProgram, pk=program_id)
    if request.method == 'POST':
        form = TrainingMaterialForm(request.POST)
        if form.is_valid():
            material = form.save(commit=False)
            material.program = program
            material.save()
            return redirect('training_program_detail', program_id=program_id)
    else:
        form = TrainingMaterialForm()
    return render(request, 'tms/create_material.html', {'form': form, 'program': program})

# Similar to update_training_program, delete_training_program, etc.
# ...
---------------------
# views.py in the tms app

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import TrainingProgram, TrainingMaterial, TrainingModule, Quiz, Trainer, TrainingSession
from .forms import TrainingProgramForm, TrainingMaterialForm, TrainingModuleForm, QuizForm, TrainerForm, TrainingSessionForm

@login_required
def training_program_list(request):
    programs = TrainingProgram.objects.all()
    return render(request, 'tms/program_list.html', {'programs': programs})

# Similar to other views

@login_required
def create_training_program(request):
    if request.method == 'POST':
        form = TrainingProgramForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('training_program_list')
    else:
        form = TrainingProgramForm()
    return render(request, 'tms/create_program.html', {'form': form})

# Similar to other CRUD views

@login_required
def create_training_material(request, program_id):
    program = get_object_or_404(TrainingProgram, pk=program_id)
    if request.method == 'POST':
        form = TrainingMaterialForm(request.POST, request.FILES)
        if form.is_valid():
            material = form.save(commit=False)
            material.program = program
            material.save()
            return redirect('training_program_detail', program_id=program_id)
    else:
        form = TrainingMaterialForm()
    return render(request, 'tms/create_material.html', {'form': form, 'program': program})

# Similar to other CRUD views

# Add more views for other features

# views.py in the tms app

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import TrainingProgram, TrainingMaterial, TrainingModule, Quiz, Trainer, TrainingSession
from .forms import TrainingProgramForm, TrainingMaterialForm, TrainingModuleForm, QuizForm, TrainerForm, TrainingSessionForm

@login_required
def training_program_list(request):
    programs = TrainingProgram.objects.all()
    return render(request, 'tms/program_list.html', {'programs': programs})

@login_required
def training_program_detail(request, program_id):
    program = get_object_or_404(TrainingProgram, pk=program_id)
    return render(request, 'tms/program_detail.html', {'program': program})

@login_required
def create_training_program(request):
    if request.method == 'POST':
        form = TrainingProgramForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('training_program_list')
    else:
        form = TrainingProgramForm()
    return render(request, 'tms/create_program.html', {'form': form})

@login_required
def update_training_program(request, program_id):
    program = get_object_or_404(TrainingProgram, pk=program_id)
    if request.method == 'POST':
        form = TrainingProgramForm(request.POST, instance=program)
        if form.is_valid():
            form.save()
            return redirect('training_program_list')
    else:
        form = TrainingProgramForm(instance=program)
    return render(request, 'tms/update_program.html', {'form': form, 'program': program})

@login_required
def delete_training_program(request, program_id):
    program = get_object_or_404(TrainingProgram, pk=program_id)
    if request.method == 'POST':
        program.delete()
        return redirect('training_program_list')
    return render(request, 'tms/delete_program.html', {'program': program})

@login_required
def create_training_material(request, program_id):
    program = get_object_or_404(TrainingProgram, pk=program_id)
    if request.method == 'POST':
        form = TrainingMaterialForm(request.POST, request.FILES)
        if form.is_valid():
            material = form.save(commit=False)
            material.program = program
            material.save()
            return redirect('training_program_detail', program_id=program_id)
    else:
        form = TrainingMaterialForm()
    return render(request, 'tms/create_material.html', {'form': form, 'program': program})

@login_required
def update_training_material(request, material_id):
    material = get_object_or_404(TrainingMaterial, pk=material_id)
    if request.method == 'POST':
        form = TrainingMaterialForm(request.POST, request.FILES, instance=material)
        if form.is_valid():
            form.save()
            return redirect('training_program_detail', program_id=material.program.id)
    else:
        form = TrainingMaterialForm(instance=material)
    return render(request, 'tms/update_material.html', {'form': form, 'material': material})

@login_required
def delete_training_material(request, material_id):
    material = get_object_or_404(TrainingMaterial, pk=material_id)
    program_id = material.program.id
    if request.method == 'POST':
        material.delete()
        return redirect('training_program_detail', program_id=program_id)
    return render(request, 'tms/delete_material.html', {'material': material})

# Similar CRUD views for TrainingModule, Quiz, Trainer, TrainingSession
# views.py in the tms app

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import TrainingProgram, TrainingMaterial, TrainingModule, Quiz, Trainer, TrainingSession
from .forms import TrainingProgramForm, TrainingMaterialForm, TrainingModuleForm, QuizForm, TrainerForm, TrainingSessionForm

# ... Previous views ...

@login_required
def create_training_module(request, program_id):
    program = get_object_or_404(TrainingProgram, pk=program_id)
    if request.method == 'POST':
        form = TrainingModuleForm(request.POST)
        if form.is_valid():
            module = form.save(commit=False)
            module.program = program
            module.save()
            return redirect('training_program_detail', program_id=program_id)
    else:
        form = TrainingModuleForm()
    return render(request, 'tms/create_module.html', {'form': form, 'program': program})

@login_required
def update_training_module(request, module_id):
    module = get_object_or_404(TrainingModule, pk=module_id)
    if request.method == 'POST':
        form = TrainingModuleForm(request.POST, instance=module)
        if form.is_valid():
            form.save()
            return redirect('training_program_detail', program_id=module.program.id)
    else:
        form = TrainingModuleForm(instance=module)
    return render(request, 'tms/update_module.html', {'form': form, 'module': module})

@login_required
def delete_training_module(request, module_id):
    module = get_object_or_404(TrainingModule, pk=module_id)
    program_id = module.program.id
    if request.method == 'POST':
        module.delete()
        return redirect('training_program_detail', program_id=program_id)
    return render(request, 'tms/delete_module.html', {'module': module})

# Similar CRUD views for Quiz, Trainer, TrainingSession
# views.py in the tms app

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import TrainingProgram, TrainingMaterial, TrainingModule, Quiz, Trainer, TrainingSession
from .forms import TrainingProgramForm, TrainingMaterialForm, TrainingModuleForm, QuizForm, TrainerForm, TrainingSessionForm

# ... Previous views ...

@login_required
def create_quiz(request, module_id):
    module = get_object_or_404(TrainingModule, pk=module_id)
    if request.method == 'POST':
        form = QuizForm(request.POST)
        if form.is_valid():
            quiz = form.save(commit=False)
            quiz.module = module
            quiz.save()
            return redirect('training_module_detail', module_id=module_id)
    else:
        form = QuizForm()
    return render(request, 'tms/create_quiz.html', {'form': form, 'module': module})

@login_required
def update_quiz(request, quiz_id):
    quiz = get_object_or_404(Quiz, pk=quiz_id)
    if request.method == 'POST':
        form = QuizForm(request.POST, instance=quiz)
        if form.is_valid():
            form.save()
            return redirect('training_module_detail', module_id=quiz.module.id)
    else:
        form = QuizForm(instance=quiz)
    return render(request, 'tms/update_quiz.html', {'form': form, 'quiz': quiz})

@login_required
def delete_quiz(request, quiz_id):
    quiz = get_object_or_404(Quiz, pk=quiz_id)
    module_id = quiz.module.id
    if request.method == 'POST':
        quiz.delete()
        return redirect('training_module_detail', module_id=module_id)
    return render(request, 'tms/delete_quiz.html', {'quiz': quiz})

@login_required
def create_trainer(request):
    if request.method == 'POST':
        form = TrainerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('trainer_list')
    else:
        form = TrainerForm()
    return render(request, 'tms/create_trainer.html', {'form': form})

@login_required
def update_trainer(request, trainer_id):
    trainer = get_object_or_404(Trainer, pk=trainer_id)
    if request.method == 'POST':
        form = TrainerForm(request.POST, instance=trainer)
        if form.is_valid():
            form.save()
            return redirect('trainer_list')
    else:
        form = TrainerForm(instance=trainer)
    return render(request, 'tms/update_trainer.html', {'form': form, 'trainer': trainer})

@login_required
def delete_trainer(request, trainer_id):
    trainer = get_object_or_404(Trainer, pk=trainer_id)
    if request.method == 'POST':
        trainer.delete()
        return redirect('trainer_list')
    return render(request, 'tms/delete_trainer.html', {'trainer': trainer})

@login_required
def create_training_session(request):
    if request.method == 'POST':
        form = TrainingSessionForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('training_session_list')
    else:
        form = TrainingSessionForm()
    return render(request, 'tms/create_session.html', {'form': form})

@login_required
def update_training_session(request, session_id):
    session = get_object_or_404(TrainingSession, pk=session_id)
    if request.method == 'POST':
        form = TrainingSessionForm(request.POST, instance=session)
        if form.is_valid():
            form.save()
            return redirect('training_session_list')
    else:
        form = TrainingSessionForm(instance=session)
    return render(request, 'tms/update_session.html', {'form': form, 'session': session})

@login_required
def delete_training_session(request, session_id):
    session = get_object_or_404(TrainingSession, pk=session_id)
    if request.method == 'POST':
        session.delete()
        return redirect('training_session_list')
    return render(request, 'tms/delete_session.html', {'session': session})


# views.py in the tms app

from django.shortcuts import render, redirect
from .models import TrainingRequest
from .forms import TrainingRequestForm


def submit_request_employee_to_manager(request):
    if request.method == 'POST':
        form = TrainingRequestForm(request.POST)
        if form.is_valid():
            request_instance = form.save(commit=False)
            request_instance.sender = request.user
            request_instance.receiver = form.cleaned_data['receiver']
            request_instance.receiver_type = 'manager'
            request_instance.save()
            return redirect('home')  # Redirect to the home page or a confirmation page
    else:
        form = TrainingRequestForm()

    return render(request, 'submit_request.html', {'form': form})


# views.py in the tms app

def submit_request_employee_to_trainer(request):
    if request.method == 'POST':
        form = TrainingRequestForm(request.POST)
        if form.is_valid():
            request_instance = form.save(commit=False)
            request_instance.sender = request.user
            request_instance.receiver = form.cleaned_data['receiver']
            request_instance.receiver_type = 'trainer'
            request_instance.save()
            return redirect('home')  # Redirect to the home page or a confirmation page
    else:
        form = TrainingRequestForm()

    return render(request, 'submit_request.html', {'form': form})


# views.py in the tms app

from django.shortcuts import render, redirect
from .models import TrainingRequest, Room, TrainerAvailability


def schedule_training(request, request_id):
    training_request = TrainingRequest.objects.get(id=request_id)
    available_rooms = Room.objects.all()
    available_trainers = TrainerAvailability.objects.filter(date=training_request.scheduled_date,
                                                            start_time__lte=training_request.start_time,
                                                            end_time__gte=training_request.end_time)
    if request.method == 'POST':
        room_id = request.POST.get('room')
        trainer_id = request.POST.get('trainer')
        room = Room.objects.get(id=room_id)
        trainer = Cus.objects.get(id=trainer_id)

        # Update the training request's room and trainer
        training_request.room = room
        training_request.trainer = trainer
        training_request.status = 'approved'
        training_request.save()

        # Notify the trainer and manager/employee
        # Implement your notification logic here

        return redirect('home')  # Redirect to the home page or a confirmation page

    return render(request, 'schedule_training.html', {'training_request': training_request,
                                                      'available_rooms': available_rooms,
                                                      'available_trainers': available_trainers})


# views.py in the tms app

from django.shortcuts import render, redirect
from .models import TrainingRequest
from .forms import TrainingRequestForm  # You'll need to create this form


def submit_request(request):
    if request.method == 'POST':
        form = TrainingRequestForm(request.POST)
        if form.is_valid():
            request_instance = form.save(commit=False)
            request_instance.employee = request.user
            request_instance.save()
            return redirect('home')  # Redirect to the home page or a confirmation page
    else:
        form = TrainingRequestForm()

    return render(request, 'submit_request.html', {'form': form})


def pending_requests_view(request):
    pending_requests = TrainingRequest.objects.pending_requests()
    return render(request, 'pending_requests.html', {'pending_requests': pending_requests})


# views.py in the tms app

from django.shortcuts import render, redirect
from .models import TrainingRequest, Room, TrainerAvailability


def schedule_training(request, request_id):
    training_request = TrainingRequest.objects.get(id=request_id)
    available_rooms = Room.objects.all()
    available_trainers = TrainerAvailability.objects.filter(date=training_request.scheduled_date,
                                                            start_time__lte=training_request.start_time,
                                                            end_time__gte=training_request.end_time)
    if request.method == 'POST':
        room_id = request.POST.get('room')
        trainer_id = request.POST.get('trainer')
        room = Room.objects.get(id=room_id)
        trainer = User.objects.get(id=trainer_id)

        # Update the training request's room and trainer
        training_request.room = room
        training_request.trainer = trainer
        training_request.status = 'approved'
        training_request.save()

        # Notify the trainer and manager/employee
        # Implement your notification logic here

        return redirect('home')  # Redirect to the home page or a confirmation page

    return render(request, 'schedule_training.html', {'training_request': training_request,
                                                      'available_rooms': available_rooms,
                                                      'available_trainers': available_trainers})


# views.py in the tms app

from django.shortcuts import render, redirect
from .models import TrainingRequest, TrainingSession


def start_training(request, request_id):
    training_request = TrainingRequest.objects.get(id=request_id)

    if request.method == 'POST':
        # Create a new TrainingSession instance
        session = TrainingSession.objects.create(
            sender=request.user,
            receiver=training_request.trainer,
            training_request=training_request,
            start_time=training_request.start_time,
            end_time=training_request.end_time,
            status='ongoing'
        )
        session.attendance.set([training_request.employee])  # Mark the employee as attended

        # Notify relevant parties about the training session
        # Implement your notification logic here

        return redirect('home')  # Redirect to the home page or a confirmation page

    return render(request, 'start_training.html', {'training_request': training_request})


# views.py in the tms app

from django.shortcuts import render, redirect
from .models import TrainingRequest, TrainingSession, Attendance


def start_training(request, request_id):
    training_request = TrainingRequest.objects.get(id=request_id)

    if request.method == 'POST':
        # Create a new TrainingSession instance
        session = TrainingSession.objects.create(
            sender=request.user,
            receiver=training_request.trainer,
            training_request=training_request,
            start_time=training_request.start_time,
            end_time=training_request.end_time,
            scheduled_date=training_request.scheduled_date,
            scheduled_start_time=training_request.start_time,
            scheduled_end_time=training_request.end_time,
            status='ongoing'
        )

        # Notify relevant parties about the training session
        # Implement your notification logic here

        return redirect('home')  # Redirect to the home page or a confirmation page

    return render(request, 'start_training.html', {'training_request': training_request})


def mark_attendance(request, session_id):
    session = TrainingSession.objects.get(id=session_id)

    if request.method == 'POST':
        employee_id = request.POST.get('employee')
        employee = User.objects.get(id=employee_id)

        # Mark attendance for the employee in the Attendance model
        attendance, created = Attendance.objects.get_or_create(session=session, employee=employee)
        attendance.marked = True
        attendance.save()

        return redirect('mark_attendance', session_id=session_id)

    # Fetch employees who haven't marked attendance
    unmarked_employees = User.objects.exclude(attended_sessions__session=session)

    return render(request, 'mark_attendance.html', {'session': session, 'unmarked_employees': unmarked_employees})


# views.py in the tms app

def create_trainer_feedback_question(request):
    if request.method == 'POST':
        question_text = request.POST.get('question_text')
        question = TrainerFeedbackQuestion.objects.create(question_text=question_text)
        return redirect('list_trainer_feedback_questions')

    return render(request, 'create_trainer_feedback_question.html')


def list_trainer_feedback_questions(request):
    questions = TrainerFeedbackQuestion.objects.all()
    return render(request, 'list_trainer_feedback_questions.html', {'questions': questions})


def submit_trainer_feedback(request, session_id):
    session = TrainingSession.objects.get(id=session_id)
    questions = TrainerFeedbackQuestion.objects.all()

    if request.method == 'POST':
        for question in questions:
            feedback_text = request.POST.get(f'feedback_{question.id}')
            TrainerFeedback.objects.create(session=session, question=question, feedback_text=feedback_text)

        return redirect('home')  # Redirect to the home page or a confirmation page

    return render(request, 'submit_trainer_feedback.html', {'session': session, 'questions': questions})


# views.py in the tms app

def create_module_feedback_question(request):
    if request.method == 'POST':
        question_text = request.POST.get('question_text')
        question = ModuleFeedbackQuestion.objects.create(question_text=question_text)
        return redirect('list_module_feedback_questions')

    return render(request, 'create_module_feedback_question.html')


def list_module_feedback_questions(request):
    questions = ModuleFeedbackQuestion.objects.all()
    return render(request, 'list_module_feedback_questions.html', {'questions': questions})


def submit_module_feedback(request, session_id):
    session = TrainingSession.objects.get(id=session_id)
    questions = ModuleFeedbackQuestion.objects.all()

    if request.method == 'POST':
        for question in questions:
            feedback_text = request.POST.get(f'feedback_{question.id}')
            ModuleFeedback.objects.create(session=session, question=question, feedback_text=feedback_text)

        return redirect('home')  # Redirect to the home page or a confirmation page

    return render(request, 'submit_module_feedback.html', {'session': session, 'questions': questions})


from django.db import transaction
from django.contrib import messages


def schedule_training(request, request_id):
    training_request = TrainingRequest.objects.get(id=request_id)
    available_rooms = Room.objects.all()
    available_trainers = TrainerAvailability.objects.filter(date=training_request.scheduled_date,
                                                            start_time__lte=training_request.start_time,
                                                            end_time__gte=training_request.end_time)
    if request.method == 'POST':
        room_id = request.POST.get('room')
        trainer_id = request.POST.get('trainer')
        room = Room.objects.get(id=room_id)
        trainer = User.objects.get(id=trainer_id)

        # Use a database transaction to ensure atomicity
        with transaction.atomic():
            try:
                # Update the training request's room and trainer
                training_request.room = room
                training_request.trainer = trainer
                training_request.status = 'approved'
                training_request.save()

                # Update the trainer's availability schedule
                trainer_availability = available_trainers.get(trainer=trainer)
                trainer_availability.delete()

                # Notify the trainer and manager/employee
                # Implement your notification logic here

                messages.success(request, 'Training scheduled successfully.')
                return redirect('home')  # Redirect to the home page or a confirmation page
            except Exception as e:
                transaction.set_rollback(True)
                messages.error(request, 'An error occurred. Please try again.')

    return render(request, 'schedule_training.html', {'training_request': training_request,
                                                      'available_rooms': available_rooms,
                                                      'available_trainers': available_trainers})
