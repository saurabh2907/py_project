from rest_framework import serializers
from .models import *

class PermissionCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = PermissionCategory
        fields = '__all__'

class PermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permission
        fields = '__all__'

class RoleSerializer(serializers.ModelSerializer):
    permissions = PermissionSerializer(many=True, read_only=True)

    class Meta:
        model = Role
        fields = '__all__'

class CustomGroupSerializer(serializers.ModelSerializer):
    role = RoleSerializer()

    class Meta:
        model = CustomGroup
        fields = '__all__'

class SkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = Skills
        fields = ['name']

class UserProfileSerializer(serializers.ModelSerializer):
    skills = SkillSerializer(many=True,read_only=True)
    class Meta:
        model = UserProfile
        fields = ['date_of_birth','gender','bio','address','photo','website','linkedin_profile','twitter_handle','skills',]

class DesignationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Designation
        fields = ['name']

class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields =['name']


class CustomUserSerializer(serializers.ModelSerializer):
    userprofile = UserProfileSerializer
    designation = DesignationSerializer
    department = DepartmentSerializer

    class Meta:
        model = CustomUser
        fields = ['id','username','password','first_name','last_name','emp_id','designation','department','phone_number'
                  'role','userprofile']
        extra_kwargs ={
            'password': {'write_only':True},
        }

    def create(self, validated_data):
        profile_data = validated_data.pop('userprofile')
        password = validated_data.pop('password')
        user = CustomUser(**validated_data)
        user.set_password(password)
        user.save()
        UserProfile.objects.create(user=user, **profile_data)
        return user
