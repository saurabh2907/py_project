from django.shortcuts import render,redirect
from .models import *
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
# Create your views here.

@login_required
def user_profile(request):
    user = request.user
    profile = user.userprofile  # Assuming UserProfile has a OneToOneField to CustomUser
    data = {
        'username': user.username,
        'email': user.email,
        'role': user.role,
        'phone_number': profile.phone_number,
        'address': profile.address,
        'photo': profile.photo.url if profile.photo else None,
        # Add other fields
    }
    return JsonResponse(data)

# views.py in the accounts app

@login_required
def edit_profile(request):
    user = request.user
    profile = user.userprofile
    if request.method == 'POST':
        # Process form data and update the profile
        # Redirect to the profile page or any other page
        return redirect('user_profile')
    return render(request, 'accounts/edit_profile.html', {'user': user, 'profile': profile})
