from rest_framework import status
from rest_framework.decorators import api_view,permission_classes
from rest_framework.response import Response
from .serializers import *
from .models import *
from django.contrib.auth import authenticate
from django.contrib.auth.hashers import make_password
from rest_framework.permissions import IsAuthenticated,IsAdminUser
from rest_framework_simplejwt.tokens import RefreshToken

@api_view(['POST'])
def register_user(request):
    if request.method == 'POST':
        serializer = CustomUserSerializer(data=request.data)
        if serializer.is_valid():
            # Check uniqueness of username, phone_number, and emp_id
            username = serializer.validated_data['username']
            phone_number = serializer.validated_data['phone_number']
            emp_id = serializer.validated_data['emp_id']

            if CustomUser.objects.filter(username=username).exists():
                return Response({"error": "Username already exists"}, status=status.HTTP_400_BAD_REQUEST)

            if CustomUser.objects.filter(phone_number=phone_number).exists():
                return Response({"error": "Phone number already exists"}, status=status.HTTP_400_BAD_REQUEST)

            if CustomUser.objects.filter(emp_id=emp_id).exists():
                return Response({"error": "Employee ID already exists"}, status=status.HTTP_400_BAD_REQUEST)

            serializer.save()
            return Response({"message": "Registration successful"}, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def custom_login(request):
    if request.method == 'POST':
        username = request.data.get('username')
        password = request.data.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            refresh = RefreshToken.for_user(user)
            access_token = str(refresh.access_token)

            if user.role == 'admin':
                dashboard_url = 'admin_dashboard'  # Replace with your admin dashboard URL

            elif user.role == 'manager':
                dashboard_url = 'manager_dashboard'  # Replace with your manager dashboard URL

            elif user.role == 'employee':
                dashboard_url = 'employee_dashboard'  # Replace with your employee dashboard URL

            elif user.role == 'trainer':
                dashboard_url = 'trainer_dashboard'  # Replace with your trainer dashboard URL

            return Response({
                "access_token": access_token,
                "message": "Login successful",
                "dashboard_url": dashboard_url
            }, status=status.HTTP_200_OK)
        else:
            return Response({"error": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
def forget_password(request):
    if request.method == 'POST':
        username = request.data.get('username')
        phone_number = request.data.get('phone_number')
        emp_id = request.data.get('emp_id')
        try:
            user = CustomUser.objects.get(username=username,phone_number=phone_number, emp_id=emp_id)
        except CustomUser.DoseNotExist:
            return Response({"error":"User not found"}, status=status.HTTP_400_BAD_REQUEST)

        request.session['reset_password_user_id'] = user.id

        return Response({"message": "User verified for password reset"}, status=status.HTTP_200_OK)


@api_view(['POST'])
def reset_password(request):
    if request.method == 'POST':
        new_password = request.data.get('new_password')

        user_id = request.session.get('reset_password_user_id')

        if user_id:
            try:
                user = CustomUser.objects.get(id=user_id)
                user.set_password(new_password)
                user.save()

                # Clear the stored user ID from the session
                del request.session['reset_password_user_id']

                return Response({"message": "Password reset successful"}, status=status.HTTP_200_OK)
            except CustomUser.DoesNotExist:
                return Response({"error": "User not found"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"error": "User not verified for password reset"}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def view_profile(request):
    user_profile = UserProfile.objects.get(user=request.user)
    serializer = UserProfileSerializer(user_profile)
    return Response(serializer.data)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def edit_profile(request):
    user_profile = UserProfile.objects.get(user=request.user)
    serializer = UserProfileSerializer(user_profile)
    return Response(serializer.data)


@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_profile(request):
    user_profile = UserProfile.objects.get(user=request.user)
    serializer = UserProfileSerializer(user_profile, data=request.data)

    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    else:
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def change_password(request):
    user = request.user

    old_password = request.data.get('old_password')
    new_password = request.data.get('new_password')

    if user.check_password(old_password):
        user.password = make_password(new_password)
        user.save()
        return Response({"message": "Password changed successfully"}, status=status.HTTP_200_OK)
    else:
        return Response({"error": "Invalid old password"}, status=status.HTTP_400_BAD_REQUEST)




@api_view(['PUT'])
@permission_classes([IsAuthenticated, IsAdminUser])
def update_user_role(request, user_id):
    try:
        user = CustomUser.objects.get(id=user_id)
    except CustomUser.DoesNotExist:
        return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)

    new_role = request.data.get('new_role')
    # Perform validation on new_role if needed

    user.role = new_role
    user.save()

    return Response({"message": "User role updated successfully"}, status=status.HTTP_200_OK)

