from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from . import views

urlpatterns = [
    # ...
    path('login/', views.custom_login, name='custom_login'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),  # Refresh token view
    path('register/', views.register_user, name='register_user'),  # Registration view
    path('view-profile/', views.view_profile, name='view_profile'),
    path('edit-profile/', views.edit_profile, name='edit_profile'),
    path('update-profile/', views.update_profile, name='update_profile'),
    path('change-password/', views.change_password, name='change_password'),

]
