from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404
from .models import Thread, Post

def thread_list(request):
    threads = Thread.objects.all()
    return render(request, 'discussion/thread_list.html', {'threads': threads})

def thread_detail(request, thread_id):
    thread = get_object_or_404(Thread, pk=thread_id)
    posts = Post.objects.filter(thread=thread)
    return render(request, 'discussion/thread_detail.html', {'thread': thread, 'posts': posts})
