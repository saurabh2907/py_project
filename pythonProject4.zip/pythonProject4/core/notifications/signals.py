# notifications/signals.py

from django.db.models.signals import post_save
from django.dispatch import receiver
from myapp.models import TrainingRequest  # Import your model here
from notifications.models import Notification

@receiver(post_save, sender=TrainingRequest)
def send_notification_on_approval(sender, instance, **kwargs):
    if instance.status == 'approved':
        content = f"Your training request for {instance.requested_program} has been approved."
        Notification.objects.create(sender=instance.manager, receiver=instance.employee, content=content)



from django.db.models.signals import post_save
from django.dispatch import receiver
from myapp.models import TrainingRequest  # Import your model here
from notifications.models import Notification

@receiver(post_save, sender=TrainingRequest)
def send_notification_on_request_status_change(sender, instance, **kwargs):
    if instance.status_changed():
        content = f"Your training request for {instance.requested_program} has been {instance.get_status_display()}."
        Notification.objects.create(sender=instance.manager, receiver=instance.employee, content=content)
