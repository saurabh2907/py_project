from django.db import models
from core.accounts.models import CustomUser



class Tag(models.Model):
    name = models.CharField(max_length=50)

class Category(models.Model):
    name = models.CharField(max_length=50)

class Course(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    author = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True)
    url = models.URLField(null=True, blank=True)
    image = models.ImageField(upload_to='course_images/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    duration = models.CharField(max_length=50, blank=True)
    difficulty_level = models.CharField(max_length=50, blank=True)
    certificate_name = models.CharField(max_length=200, blank=True)
    certificate_design = models.ImageField(upload_to='certificate_designs/', blank=True)
    course_format = models.CharField(max_length=50, choices=[('self-paced', 'Self-Paced'), ('instructor-led', 'Instructor-Led')])
    tags = models.ManyToManyField(Tag)
    categories = models.ManyToManyField(Category)

    def __str__(self):
        return self.title



class Module(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    order = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.title} - {self.course}"


class Lesson(models.Model):
    module = models.ForeignKey(Module, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    content = models.TextField()

    def __str__(self):
        return f"{self.title} - {self.module}"


class VideoLesson(models.Model):
    lesson = models.OneToOneField(Lesson, on_delete=models.CASCADE)
    video_url = models.URLField()

    def __str__(self):
        return f"Video: {self.lesson.title} - {self.lesson.module.course}"


class LessonResource(models.Model):
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    resource_type = models.CharField(max_length=50, choices=[('pdf', 'PDF'), ('link', 'Link')])
    resource_file = models.FileField(upload_to='lesson_resources/', blank=True, null=True)
    resource_link = models.URLField(blank=True, null=True)

    def __str__(self):
        return f"{self.title} - {self.lesson}"


class Assignment(models.Model):
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    description = models.TextField()
    due_date = models.DateTimeField()

    def __str__(self):
        return f"{self.title} - {self.lesson}"


class ReadingMaterial(models.Model):
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    content = models.TextField()

    def __str__(self):
        return f"{self.title} - {self.lesson}"

class CourseReview(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.PositiveIntegerField()
    review = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)


class LiveSession(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    scheduled_datetime = models.DateTimeField()
    webinar_url = models.URLField()


from django.db import models
from django.contrib.auth.models import User
from courses.models import Course, Lesson  # Import as per your project's structure

class UserActivityLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    is_completed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user} - {self.course} - {self.lesson}"

class UserVideoProgress(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    video_timestamp = models.DurationField()
    is_completed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user} - {self.lesson} - {self.video_timestamp}"

class UserQuizAttempt(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    score = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.user} - {self.lesson} - Score: {self.score}"



from django.db import models
from django.contrib.auth.models import User
from .models import Course  # Import the Course model as per your project structure

class UserEnrollment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    enrollment_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user} enrolled in {self.course}"
