# common/serializers.py

from rest_framework import serializers
from core.tms.models import TrainingRequest,

class TrainerDashboardSerializer(serializers.Serializer):
    upcoming_sessions = serializers.ListField(child=serializers.DictField())
    notifications = serializers.ListField(child=serializers.DictField())
