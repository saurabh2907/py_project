# notifications/views.py

from django.shortcuts import render, redirect
from .models import Notification

def list_notifications(request):
    user = request.user
    notifications = Notification.objects.filter(receiver=user).order_by('-created_at')
    return render(request, 'notifications/list_notifications.html', {'notifications': notifications})

def mark_as_read(request, notification_id):
    notification = Notification.objects.get(id=notification_id)
    notification.is_read = True
    notification.save()
    return redirect('list_notifications')
