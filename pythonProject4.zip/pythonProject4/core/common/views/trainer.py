from core.tms.serializers import *
from  rest_framework import viewsets,permissions

class TrainerDashboardViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = 